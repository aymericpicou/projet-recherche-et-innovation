package fr.tse.lt2c.satin;
import java.awt.Graphics;
import java.util.Map;

import javax.swing.JPanel;
public class mypanel extends JPanel { 
	Map<String, double[]> CoordCartesien;
	private static final long serialVersionUID = 1L;
	int zoom=100;
	public mypanel(Map<String, double[]> coordCartesien){
		CoordCartesien=coordCartesien;
	}
	public void paintComponent(Graphics g){

		   double[] tab;
		   int coord1;
		   int coord2;
		   int i=0;
		   
		    for (String user : CoordCartesien.keySet()) {//on concatene tout les tweet dans une seule chaine de caractere
		    	if(user!=null && user!="" && (CoordCartesien.get(user)[0]!=0 || CoordCartesien.get(user)[1]!=0)){
		    	tab=CoordCartesien.get(user);
		    	coord1=(this.getWidth()/2)+(int)(tab[0]*zoom);
		    	coord2=(this.getHeight()/2)+(int)(tab[1]*zoom);
		    	 g.fillOval(coord1,coord2, 5, 5);
		    	 
		    	 //g.drawString(user, coord1,coord2);
		    	 i++;
			}
		    }
		    for(int j=0;j<this.getHeight();j++){
		    	g.fillOval(this.getWidth()/2,j, 2, 2);
		    }
		    for(int j=0;j<this.getWidth();j++){
		    	g.fillOval(j,this.getHeight()/2, 2, 2);
		    }
		  }               
		}
