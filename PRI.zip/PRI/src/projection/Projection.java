package projection;

import java.util.HashMap;
import java.util.Map;
import java.math.BigDecimal;

public class Projection {
	
	Map<String, double[]> coord;
	int user;
	int nbtopic;
	Map<String, double[]> coeff;
	
	
		
	/**
	 * @param args
	 */
	public Projection(Map<String, double[]> coo, int topic, int profil){
		user=profil;
		nbtopic =topic;
		coord = coo;
		coeff = new HashMap<String,double[]>();
	}
	
	
	 public static double getPearsonCorrelation(double[] scores1,double[] scores2){// Calcul le coefficient de corr�lation
	    	
	        double result = 0;
	        double sum_sq_x = 0;
	        double sum_sq_y = 0;
	        double sum_coproduct = 0;
	        double mean_x = scores1[0];
	        double mean_y = scores2[0];
	        for(int i=2;i<scores1.length+1;i+=1){
	            double sweep =Double.valueOf(i-1)/i;
	            double delta_x = scores1[i-1]-mean_x;
	            double delta_y = scores2[i-1]-mean_y;
	            sum_sq_x += delta_x * delta_x * sweep;
	            sum_sq_y += delta_y * delta_y * sweep;
	            sum_coproduct += delta_x * delta_y * sweep;
	            mean_x += delta_x / i;
	            mean_y += delta_y / i;
	        }
	        double pop_sd_x = (double) Math.sqrt(sum_sq_x/scores1.length);
	        double pop_sd_y = (double) Math.sqrt(sum_sq_y/scores1.length);
	        double cov_x_y = sum_coproduct / scores1.length;
	        result = cov_x_y / (pop_sd_x*pop_sd_y);
	        return result;
	    }
	
	
	
	

	
public double [][] ini(double [][] tab,int topic){ // initialise le tableau de coefficient
	
		for (int j=0;j<user;j++) {//pour chaque utilisateur
			 
			
			for(int i=0;i<topic;i++){//on initialise toute les coordonn�es � 0
				tab[j][i]=0.0;
			}
			
			
		}
		return tab;
	}
	
	
	
	
	public void affiche_Coord(){ // affiche un hmap
		for (String map : coord.keySet()) {
			for(int i=0;i<nbtopic;i++){
				System.out.print(coord.get(map)[i]+"\t");
			}
			System.out.println();
		}
	}
	
	
	public Map<String, double[]> calculCoeffCorrelation() // calcul du coefficient de corr�lation
	{
		
		//initialisation
		double [][] tampon =new double [user][nbtopic];
		double [] tab1 = new double [user];
		double [] tab2 = new double [user];
		
		tampon = ini(tampon,nbtopic);
		
		
		for(int m=0;m<nbtopic;m++)
		{
			tab1[m]=0;
			tab2[m]=0;
		}
			
		//calcul du coefficient de correlation et on l'insere dans le tampon
		
		for(int i=0;i<nbtopic;i++){
		for( int j=0;j<nbtopic;j++){
			int k =0;
			for (String map : coord.keySet()) {
				
			tab1[k]=coord.get(map)[i];
			tab2[k]=coord.get(map)[j];
			k++;
			}
		tampon[i][j]=getPearsonCorrelation(tab1,tab2); // calcul du coefficient de corr�lation
		
		
	}
		}
		
		// on affiche la matrice de correlation
		System.out.println();
		for(int l=0;l<nbtopic;l++){
				for(int k=0;k<nbtopic;k++){
					System.out.print(tampon[l][k]+"\t");
				}
				System.out.println();
			}
			System.out.println();
			
		// on groupe les axes 2 � 2 en fonction de leur correlation
			//initialisation
			double [] max = new double[nbtopic];
			int [] axe1 = new int [nbtopic];
			int [] axe2 = new int [nbtopic];
			
			//calcul
		for(int i=0;i<nbtopic;i++){
			max[i]=0;
			for(int j=0;i>j;j++){
				
					if(tampon[j][i]<1-0.0000000001){
						if(max[i]<=tampon[j][i] ){
							
							axe1[i]=i;
							axe2[i]=j;
							max[i]=tampon[j][i];
						}
						
					}
				
			
			}
		
		}
		
		
		
		
		
		
		// On selectionne les axes � regrouper et on r�duit la dimension de la matrice de correlation
		
		
		
		for( int j=0;j<nbtopic;j++){
			System.out.print(axe1[j]+"\t");
			
			}
		System.out.println();
		for( int j=0;j<nbtopic;j++){
		
			System.out.print(axe2[j]+"\t");
			}
			System.out.println();
		for( int j=0;j<nbtopic;j++){
		
			System.out.print(max[j]+"\t");
			}
		double memoire=0;
		int [] winner1 = new int[nbtopic];
		int [] winner2 = new int[nbtopic];
		int k=0;

		for(int j=0;j<nbtopic;j++){
		
		for(int i=0;i<nbtopic;i++){
			
			
				if(memoire<max[i] ){
					
					winner1[j]=axe1[i];
					winner2[j]=axe2[i];
					memoire=max[i];
				}
				
			}
		
				System.out.println();
				k=0;
				while(memoire!=0)
				{
					if(max[k]== memoire){
						max[k]=0;
						memoire=0;
					}
					k++;
				}
				if(winner1[j]==0 && winner2[j]==0)
				{
					winner1[j]=-1;
					winner2[j]=-1;
				}
		}
		
		for( int j=0;j<nbtopic;j++){
			System.out.print(winner1[j]+"\t");
			
			}
		System.out.println();
		for( int j=0;j<nbtopic;j++){
		
			System.out.print(winner2[j]+"\t");
			}
			System.out.println();
		
		
		
		int[] choix = Selection(winner1,winner2,nbtopic,tampon);
		 return Fusion(coord,tampon,choix,nbtopic);
	}
	public int recherche(int nbr, int [] tab, int [] tab2)
	{
		int indice=0;
		int compteur=0;
		while( compteur<tab.length)
		{
			
			if(tab[compteur]==nbr)
			{
				indice++;
			}
			if(tab2[compteur]==nbr)
			{
				indice++;
			}
			compteur++;
		}
		return indice;
			
	}
	
	public int [] Selection(int [] win1, int [] win2, int topic, double[][] coeff){// selection des lignes � fusionner
		
		int [] tab = new int [2];
		int [][] choix=new int [topic][2];
		
		// on remplie le tableau avec des valeurs et-1, valeur : on fusionne les colonnes; -1 : on ne les fusionne pas car d�pendance avec des fusions pr�c�dentes
	
		for (int i=0 ;i<topic;i++){
			
		choix[i][0]=i;
		choix[i][1]=-1;
		}
		
		for(int i =0;i<topic;i++){

				choix[i][1]=recherche(i,win1,win2);				
	
		}
		
		int [] max1=new int [2];
		max1[1]=choix[1][0];
		max1[0]=choix[0][0];
		int [] max2=new int [2];
		max2[1]=0;
		max2[0]=0;
		
		int [] tampon = new int [2];
		
		while(coeff[max1[0]][max2[0]]>0.5){
			max2[1]=0;
			max2[0]=0;
			for(int i=0;i<nbtopic;i++){
			
			if(max1[1]<max2[1]){
				tampon[1] = max1[1];
				tampon[0] = max1[0];
				max1[1] = max2[1];
				max1[0] = max2[0];
				max2[1] = tampon[1];
				max2[0] = tampon[0];
			}
			
			if(max2[1]<choix[i][1]){
				max2[1]=choix[i][1];
				max2[0]=choix[i][0];
			}
			if(max1[1]<max2[1]){
				tampon[1] = max1[1];
				tampon[0] = max1[0];
				max1[1] = max2[1];
				max1[0] = max2[0];
				max2[1] = tampon[1];
				max2[0] = tampon[0];
			}
			
		}
		
		max1[1]=max2[0];
		}
		for( int j=0;j<nbtopic;j++){
			System.out.print(choix[j][0]+"\t");
			
			}
		System.out.println();
		for( int j=0;j<nbtopic;j++){
		
			System.out.print(choix[j][1]+"\t");
			}
			System.out.println();
		
			System.out.print("affichge des max \t");
			System.out.print(max1[0]+"\t");
			System.out.print(max1[1]+"\t");
			System.out.println();
			
		
		return max1;
	}
	
	
	public Map<String, double[]> Fusion(Map<String, double[]> tabref, double [][] coeffCorrelation, int [] axes, int topic)
	{
		// on vient projeter les users sur les 2 axes s�lectionn�s
		Map<String, double[]> tab1 = new HashMap<String,double[]>();
		
		
		for (String map : coord.keySet()) {
			double [] somme=new double [2];
			somme[0]=0;
			somme[1]=0;
			for(int j=0;j<topic;j++){
				somme[0]+=coeffCorrelation[axes[0]][j]*coord.get(map)[j];
				somme[1]+=coeffCorrelation[axes[1]][j]*coord.get(map)[j]*Math.cos((90-Math.acos(coeffCorrelation[axes[0]][axes[1]])));
			}
			
			tab1.put(map, somme);
			System.out.println(tab1.get(map)[0]);
			System.out.println(map+"\t"+somme[0]+"\t"+somme[1]);
			}
		System.out.println();
		System.out.println();

		
		
		return tab1;
	}
	
	public static void main(String[] args) {
		Map<String, double[]> coord = new HashMap<String,double[]>();// hmap de user et coordonn�es dimension n
		Map<String, double[]> coordCartesien = new HashMap<String,double[]>(); // hmap de user et coordonn�es dimension 2
		Projection test = new Projection(coord,16,15); // construction d'une projection hmap,topic,user
		test.affiche_Coord(); // affichage du hmap
		coordCartesien=test.calculCoeffCorrelation(); // calcul de la projection retournant un hmap user + coordonn�es rep�re cart�sien
	}

}


